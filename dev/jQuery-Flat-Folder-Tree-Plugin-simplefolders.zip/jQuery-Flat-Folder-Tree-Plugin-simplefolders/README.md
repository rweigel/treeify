jquery-simplefolders
====================

is simple code for a folder / tree widget for your html page